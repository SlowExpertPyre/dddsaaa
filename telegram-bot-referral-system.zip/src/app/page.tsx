"use client";

import { useEffect, useState } from "react";

export const dynamic = "force-dynamic";

interface StatsData {
  stats: {
    users: number;
    links: number;
    purchases: number;
    totalRevenue: string;
    totalCommissions: string;
    totalPaidOut: string;
  };
  top: Array<{
    telegramId: number;
    username: string | null;
    firstName: string | null;
    totalEarned: string;
  }>;
  links: Array<{
    id: number;
    code: string;
    ownerId: number;
    ownerUsername: string | null;
    clickCount: number;
    referredCount: number;
    createdAt: string;
  }>;
  purchases: Array<{
    id: number;
    buyerTelegramId: number;
    referrerTelegramId: number | null;
    amount: string;
    commission: string;
    description: string | null;
    createdAt: string;
  }>;
}

const MEDALS = ["🥇", "🥈", "🥉", "4️⃣", "5️⃣"];
const BOT_USERNAME =
  typeof window !== "undefined"
    ? (window as any).__BOT_USERNAME__ ?? "myrefbot"
    : "myrefbot";

function fmt(val: string | number | null | undefined) {
  const n = parseFloat(String(val ?? "0"));
  return (
    n.toLocaleString("ru-RU", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }) + " ₽"
  );
}

function dName(username?: string | null, firstName?: string | null) {
  if (username) return `@${username}`;
  if (firstName) return firstName;
  return "Unknown";
}

export default function AdminPage() {
  const [data, setData] = useState<StatsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<"overview" | "links" | "leaderboard" | "purchases" | "add">(
    "overview"
  );

  // Add purchase form state
  const [buyerTelegramId, setBuyerTelegramId] = useState("");
  const [purchaseAmount, setPurchaseAmount] = useState("");
  const [purchaseDesc, setPurchaseDesc] = useState("");
  const [addMsg, setAddMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [addLoading, setAddLoading] = useState(false);

  async function load() {
    setLoading(true);
    try {
      const res = await fetch("/api/admin/stats");
      const json = await res.json();
      setData(json);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    const iv = setInterval(load, 30_000);
    return () => clearInterval(iv);
  }, []);

  async function handleAddPurchase(e: React.FormEvent) {
    e.preventDefault();
    setAddLoading(true);
    setAddMsg(null);
    try {
      const res = await fetch("/api/admin/purchase", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          buyerTelegramId: parseInt(buyerTelegramId),
          amount: parseFloat(purchaseAmount),
          description: purchaseDesc || undefined,
        }),
      });
      const json = await res.json();
      if (res.ok) {
        setAddMsg({
          ok: true,
          text: `✅ Purchase recorded! Commission: ${fmt(json.commission)}`,
        });
        setBuyerTelegramId("");
        setPurchaseAmount("");
        setPurchaseDesc("");
        load();
      } else {
        setAddMsg({ ok: false, text: `❌ Error: ${json.error}` });
      }
    } catch (err) {
      setAddMsg({ ok: false, text: `❌ Network error` });
    } finally {
      setAddLoading(false);
    }
  }

  const tabs = [
    { key: "overview", label: "📊 Overview" },
    { key: "leaderboard", label: "🏆 Leaderboard" },
    { key: "links", label: "🔗 Ref Links" },
    { key: "purchases", label: "🛒 Purchases" },
    { key: "add", label: "➕ Add Purchase" },
  ] as const;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900 text-white">
      {/* Header */}
      <header className="border-b border-white/10 bg-white/5 backdrop-blur px-6 py-4">
        <div className="mx-auto max-w-7xl flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="text-3xl">🤖</span>
            <div>
              <h1 className="text-xl font-bold tracking-tight">Referral Bot Admin</h1>
              <p className="text-xs text-blue-300">@{BOT_USERNAME} · Dashboard</p>
            </div>
          </div>
          <button
            onClick={load}
            className="flex items-center gap-2 rounded-xl bg-blue-600 hover:bg-blue-500 transition px-4 py-2 text-sm font-medium"
          >
            {loading ? "⟳ Refreshing…" : "⟳ Refresh"}
          </button>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-6 py-8">
        {/* Tabs */}
        <div className="flex gap-2 mb-8 flex-wrap">
          {tabs.map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`rounded-xl px-4 py-2 text-sm font-semibold transition ${
                tab === t.key
                  ? "bg-blue-600 text-white shadow-lg shadow-blue-900/40"
                  : "bg-white/10 hover:bg-white/20 text-slate-300"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {loading && !data ? (
          <div className="flex items-center justify-center py-32">
            <div className="text-4xl animate-spin">⟳</div>
          </div>
        ) : (
          <>
            {/* OVERVIEW */}
            {tab === "overview" && data && (
              <div className="space-y-8">
                {/* Stat Cards */}
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {[
                    { label: "Total Users", value: data.stats.users, icon: "👥", color: "from-blue-600 to-blue-800" },
                    { label: "Referral Links", value: data.stats.links, icon: "🔗", color: "from-purple-600 to-purple-800" },
                    { label: "Purchases", value: data.stats.purchases, icon: "🛒", color: "from-green-600 to-green-800" },
                    { label: "Total Revenue", value: fmt(data.stats.totalRevenue), icon: "💵", color: "from-yellow-600 to-yellow-800" },
                    { label: "Total Commissions", value: fmt(data.stats.totalCommissions), icon: "💸", color: "from-orange-600 to-orange-800" },
                    { label: "Paid to Referrers", value: fmt(data.stats.totalPaidOut), icon: "💰", color: "from-emerald-600 to-emerald-800" },
                  ].map((card) => (
                    <div
                      key={card.label}
                      className={`rounded-2xl bg-gradient-to-br ${card.color} p-5 shadow-xl`}
                    >
                      <div className="text-3xl mb-2">{card.icon}</div>
                      <div className="text-2xl font-bold">{card.value}</div>
                      <div className="text-sm opacity-80 mt-1">{card.label}</div>
                    </div>
                  ))}
                </div>

                {/* Bot Commands Info */}
                <div className="rounded-2xl bg-white/5 border border-white/10 p-6">
                  <h2 className="text-lg font-semibold mb-4">📱 Bot Commands</h2>
                  <div className="grid sm:grid-cols-2 gap-3">
                    {[
                      { cmd: "/start", desc: "Start the bot, get referral link", admin: false },
                      { cmd: "/mylink", desc: "View your referral link & click stats", admin: false },
                      { cmd: "/mystats", desc: "View your personal earnings", admin: false },
                      { cmd: "/statistics", desc: "Public Top-5 earners leaderboard", admin: false },
                      { cmd: "/admin", desc: "Admin panel menu", admin: true },
                      { cmd: "/admin_stats", desc: "Overall bot statistics", admin: true },
                      { cmd: "/admin_links", desc: "All referral links with stats", admin: true },
                      { cmd: "/admin_users", desc: "All registered users", admin: true },
                      { cmd: "/admin_purchases", desc: "Recent purchases list", admin: true },
                      { cmd: "/admin_add_purchase", desc: "[userId] [amount] [desc] — record a purchase", admin: true },
                      { cmd: "/admin_top", desc: "Top 10 earners (admin view)", admin: true },
                    ].map((c) => (
                      <div
                        key={c.cmd}
                        className={`flex items-start gap-3 rounded-xl p-3 ${
                          c.admin ? "bg-orange-900/30 border border-orange-500/20" : "bg-white/5"
                        }`}
                      >
                        <code className="text-blue-300 text-sm whitespace-nowrap">{c.cmd}</code>
                        <span className="text-slate-400 text-sm">{c.desc}</span>
                        {c.admin && (
                          <span className="ml-auto text-xs bg-orange-600 text-white px-2 py-0.5 rounded-full shrink-0">
                            Admin
                          </span>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                {/* How it works */}
                <div className="rounded-2xl bg-white/5 border border-white/10 p-6">
                  <h2 className="text-lg font-semibold mb-4">⚙️ How It Works</h2>
                  <div className="grid sm:grid-cols-3 gap-4 text-sm text-slate-300">
                    {[
                      { n: "1", title: "User joins via link", desc: "User clicks a referral link like t.me/bot?start=xleremy — they're linked to the referrer." },
                      { n: "2", title: "Purchase is recorded", desc: "Admin records a purchase (via bot or this panel). The system calculates 50% commission." },
                      { n: "3", title: "Referrer earns & is notified", desc: "Commission is credited to the referrer's balance. They receive a Telegram DM notification. Admin also gets notified of new referrals." },
                    ].map((s) => (
                      <div key={s.n} className="rounded-xl bg-white/5 p-4">
                        <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center font-bold mb-3">
                          {s.n}
                        </div>
                        <div className="font-semibold mb-1">{s.title}</div>
                        <div className="opacity-70">{s.desc}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* LEADERBOARD */}
            {tab === "leaderboard" && data && (
              <div className="space-y-6">
                <div className="rounded-2xl bg-white/5 border border-white/10 overflow-hidden">
                  <div className="px-6 py-4 border-b border-white/10">
                    <h2 className="text-lg font-semibold">🏆 Top-5 Earners (Public Leaderboard)</h2>
                    <p className="text-sm text-slate-400 mt-1">Same data shown by /statistics command in bot</p>
                  </div>
                  {data.top.length === 0 ? (
                    <div className="px-6 py-12 text-center text-slate-400">No earnings recorded yet</div>
                  ) : (
                    <div className="divide-y divide-white/5">
                      {data.top.map((row, i) => (
                        <div
                          key={row.telegramId}
                          className={`flex items-center gap-4 px-6 py-4 ${i === 0 ? "bg-yellow-900/20" : ""}`}
                        >
                          <span className="text-2xl">{MEDALS[i]}</span>
                          <div className="flex-1">
                            <div className="font-semibold">
                              {dName(row.username, row.firstName)}
                            </div>
                            <div className="text-xs text-slate-400">
                              ID: {row.telegramId}
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="font-bold text-lg text-emerald-400">
                              {fmt(row.totalEarned)}
                            </div>
                            <div className="text-xs text-slate-400">earned</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Leaderboard example */}
                <div className="rounded-2xl bg-white/5 border border-white/10 p-6">
                  <h3 className="font-semibold mb-2">📱 How it looks in Telegram</h3>
                  <div className="font-mono text-sm bg-black/30 rounded-xl p-4 whitespace-pre-wrap text-slate-300">
{`🏆 Top-5 Earners

🥇 @vasya — 200.00 ₽
🥈 @petya — 150.00 ₽
🥉 @masha — 100.00 ₽
4️⃣ @kolya — 75.00 ₽
5️⃣ @sasha — 50.00 ₽

💡 Share your referral link (/mylink) and climb the leaderboard!`}
                  </div>
                </div>
              </div>
            )}

            {/* REFERRAL LINKS */}
            {tab === "links" && data && (
              <div className="rounded-2xl bg-white/5 border border-white/10 overflow-hidden">
                <div className="px-6 py-4 border-b border-white/10 flex items-center justify-between">
                  <div>
                    <h2 className="text-lg font-semibold">🔗 Referral Links</h2>
                    <p className="text-sm text-slate-400 mt-1">
                      {data.links.length} links total
                    </p>
                  </div>
                </div>
                {data.links.length === 0 ? (
                  <div className="px-6 py-12 text-center text-slate-400">
                    No referral links yet
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="text-slate-400 text-xs uppercase border-b border-white/10">
                          <th className="px-6 py-3 text-left">Owner</th>
                          <th className="px-6 py-3 text-left">Code / Link</th>
                          <th className="px-6 py-3 text-center">Clicks</th>
                          <th className="px-6 py-3 text-center">Joined</th>
                          <th className="px-6 py-3 text-left">Created</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/5">
                        {data.links.map((l) => (
                          <tr key={l.id} className="hover:bg-white/5 transition">
                            <td className="px-6 py-3 font-medium">
                              {dName(l.ownerUsername, null)}
                              <div className="text-xs text-slate-500">{l.ownerId}</div>
                            </td>
                            <td className="px-6 py-3">
                              <code className="text-blue-300 text-xs">{l.code}</code>
                              <div className="text-xs text-slate-500 mt-0.5 truncate max-w-[200px]">
                                t.me/{BOT_USERNAME}?start={l.code}
                              </div>
                            </td>
                            <td className="px-6 py-3 text-center">
                              <span className="bg-blue-900/40 text-blue-300 px-2 py-0.5 rounded-full text-xs">
                                {l.clickCount}
                              </span>
                            </td>
                            <td className="px-6 py-3 text-center">
                              <span className="bg-green-900/40 text-green-300 px-2 py-0.5 rounded-full text-xs">
                                {l.referredCount}
                              </span>
                            </td>
                            <td className="px-6 py-3 text-slate-400 text-xs">
                              {new Date(l.createdAt).toLocaleString("en-GB")}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}

            {/* PURCHASES */}
            {tab === "purchases" && data && (
              <div className="rounded-2xl bg-white/5 border border-white/10 overflow-hidden">
                <div className="px-6 py-4 border-b border-white/10">
                  <h2 className="text-lg font-semibold">🛒 Recent Purchases</h2>
                  <p className="text-sm text-slate-400 mt-1">Last 10 purchases</p>
                </div>
                {data.purchases.length === 0 ? (
                  <div className="px-6 py-12 text-center text-slate-400">
                    No purchases recorded yet. Use "Add Purchase" to record one.
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="text-slate-400 text-xs uppercase border-b border-white/10">
                          <th className="px-6 py-3 text-left">Buyer ID</th>
                          <th className="px-6 py-3 text-left">Referrer ID</th>
                          <th className="px-6 py-3 text-right">Amount</th>
                          <th className="px-6 py-3 text-right">Commission (50%)</th>
                          <th className="px-6 py-3 text-left">Description</th>
                          <th className="px-6 py-3 text-left">Date</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/5">
                        {data.purchases.map((p) => (
                          <tr key={p.id} className="hover:bg-white/5 transition">
                            <td className="px-6 py-3 font-mono text-blue-300">{p.buyerTelegramId}</td>
                            <td className="px-6 py-3 font-mono text-purple-300">
                              {p.referrerTelegramId ?? "—"}
                            </td>
                            <td className="px-6 py-3 text-right font-semibold">{fmt(p.amount)}</td>
                            <td className="px-6 py-3 text-right text-emerald-400 font-semibold">
                              {fmt(p.commission)}
                            </td>
                            <td className="px-6 py-3 text-slate-400">{p.description ?? "—"}</td>
                            <td className="px-6 py-3 text-slate-400 text-xs">
                              {new Date(p.createdAt).toLocaleString("en-GB")}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}

            {/* ADD PURCHASE */}
            {tab === "add" && (
              <div className="max-w-lg space-y-6">
                <div className="rounded-2xl bg-white/5 border border-white/10 p-6">
                  <h2 className="text-lg font-semibold mb-1">➕ Record a Purchase</h2>
                  <p className="text-sm text-slate-400 mb-6">
                    Manually record a purchase for a user. The system will automatically
                    calculate the 50% commission and credit the referrer.
                  </p>

                  <form onSubmit={handleAddPurchase} className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-300 mb-1">
                        Buyer Telegram ID
                      </label>
                      <input
                        type="number"
                        value={buyerTelegramId}
                        onChange={(e) => setBuyerTelegramId(e.target.value)}
                        placeholder="e.g. 123456789"
                        required
                        className="w-full rounded-xl bg-white/10 border border-white/20 px-4 py-2.5 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-300 mb-1">
                        Purchase Amount (₽)
                      </label>
                      <input
                        type="number"
                        value={purchaseAmount}
                        onChange={(e) => setPurchaseAmount(e.target.value)}
                        placeholder="e.g. 500"
                        required
                        min="0.01"
                        step="0.01"
                        className="w-full rounded-xl bg-white/10 border border-white/20 px-4 py-2.5 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                      {purchaseAmount && !isNaN(parseFloat(purchaseAmount)) && (
                        <p className="text-xs text-emerald-400 mt-1">
                          Commission (50%): {fmt(parseFloat(purchaseAmount) * 0.5)}
                        </p>
                      )}
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-300 mb-1">
                        Description (optional)
                      </label>
                      <input
                        type="text"
                        value={purchaseDesc}
                        onChange={(e) => setPurchaseDesc(e.target.value)}
                        placeholder="e.g. Premium subscription"
                        className="w-full rounded-xl bg-white/10 border border-white/20 px-4 py-2.5 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>

                    {addMsg && (
                      <div
                        className={`rounded-xl px-4 py-3 text-sm ${
                          addMsg.ok
                            ? "bg-emerald-900/40 border border-emerald-500/30 text-emerald-300"
                            : "bg-red-900/40 border border-red-500/30 text-red-300"
                        }`}
                      >
                        {addMsg.text}
                      </div>
                    )}

                    <button
                      type="submit"
                      disabled={addLoading}
                      className="w-full rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-50 transition py-3 font-semibold text-white"
                    >
                      {addLoading ? "Recording…" : "Record Purchase"}
                    </button>
                  </form>
                </div>

                <div className="rounded-2xl bg-white/5 border border-white/10 p-6">
                  <h3 className="font-semibold mb-3">ℹ️ What happens when you record a purchase?</h3>
                  <ul className="text-sm text-slate-400 space-y-2">
                    <li>✅ Purchase is saved to the database</li>
                    <li>✅ 50% commission is calculated automatically</li>
                    <li>✅ Commission is credited to the referrer's earnings balance</li>
                    <li>✅ Referrer receives a Telegram DM notification</li>
                    <li>✅ Leaderboard is updated in real-time</li>
                  </ul>
                </div>
              </div>
            )}
          </>
        )}
      </main>

      {/* Setup Instructions */}
      <div className="mx-auto max-w-7xl px-6 pb-12">
        <div className="rounded-2xl bg-white/5 border border-white/10 p-6 mt-4">
          <h2 className="text-lg font-semibold mb-4">🚀 Setup Instructions</h2>
          <div className="grid sm:grid-cols-2 gap-6 text-sm text-slate-300">
            <div>
              <h3 className="font-semibold text-white mb-2">1. Configure Environment Variables</h3>
              <div className="bg-black/30 rounded-xl p-4 font-mono text-xs space-y-1">
                <div><span className="text-slate-500"># .env</span></div>
                <div>TELEGRAM_BOT_TOKEN=<span className="text-yellow-300">your_token_here</span></div>
                <div>TELEGRAM_BOT_USERNAME=<span className="text-yellow-300">your_bot_username</span></div>
                <div>ADMIN_TELEGRAM_IDS=<span className="text-yellow-300">123456789,987654321</span></div>
              </div>
            </div>
            <div>
              <h3 className="font-semibold text-white mb-2">2. Set Webhook</h3>
              <div className="bg-black/30 rounded-xl p-4 font-mono text-xs space-y-1">
                <div><span className="text-slate-500"># Run once after deploy</span></div>
                <div className="text-green-300">curl -X POST \</div>
                <div className="text-green-300 pl-2">
                  "https://api.telegram.org/bot<span className="text-yellow-300">TOKEN</span>/setWebhook" \
                </div>
                <div className="text-green-300 pl-2">
                  -d "url=https://your-domain.com/api/telegram"
                </div>
              </div>
            </div>
            <div>
              <h3 className="font-semibold text-white mb-2">3. How Referral Links Work</h3>
              <p className="text-slate-400">
                Each user gets a unique link like{" "}
                <code className="text-blue-300">t.me/bot?start=xleremy</code>. When
                someone clicks it and starts the bot, they're linked to{" "}
                <strong>xleremy</strong> as their referrer permanently.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-white mb-2">4. Admin Notifications</h3>
              <p className="text-slate-400">
                Admins receive a DM every time someone joins via a referral link.
                Referrers receive a DM when their referral makes a purchase — showing
                the purchase amount and their 50% commission.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
