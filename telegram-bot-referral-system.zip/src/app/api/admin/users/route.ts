import { NextResponse } from "next/server";
import { getAllUsers } from "@/lib/bot/helpers";

export const dynamic = "force-dynamic";

export async function GET() {
  const allUsers = await getAllUsers();
  return NextResponse.json({ users: allUsers });
}
