import { NextResponse } from "next/server";
import { getTotalStats, getTopEarners, getAllReferralLinksWithStats, getRecentPurchases } from "@/lib/bot/helpers";

export const dynamic = "force-dynamic";

export async function GET() {
  const [stats, top, links, purchases] = await Promise.all([
    getTotalStats(),
    getTopEarners(5),
    getAllReferralLinksWithStats(),
    getRecentPurchases(10),
  ]);

  return NextResponse.json({ stats, top, links, purchases });
}
