import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  const TOKEN = process.env.TELEGRAM_BOT_TOKEN;
  if (!TOKEN) {
    return NextResponse.json({ error: "TELEGRAM_BOT_TOKEN not set" }, { status: 500 });
  }

  const body = await req.json().catch(() => ({}));
  const webhookUrl = body.url as string | undefined;

  if (!webhookUrl) {
    return NextResponse.json({ error: "url is required in request body" }, { status: 400 });
  }

  const res = await fetch(`https://api.telegram.org/bot${TOKEN}/setWebhook`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ url: webhookUrl }),
  });

  const data = await res.json();
  return NextResponse.json(data);
}

export async function GET() {
  const TOKEN = process.env.TELEGRAM_BOT_TOKEN;
  if (!TOKEN) {
    return NextResponse.json({ error: "TELEGRAM_BOT_TOKEN not set" }, { status: 500 });
  }

  const res = await fetch(`https://api.telegram.org/bot${TOKEN}/getWebhookInfo`);
  const data = await res.json();
  return NextResponse.json(data);
}
