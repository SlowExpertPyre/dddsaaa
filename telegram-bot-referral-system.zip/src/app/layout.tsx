import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Referral Bot Admin Panel",
  description: "Telegram referral bot admin dashboard",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
