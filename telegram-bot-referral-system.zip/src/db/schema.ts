import {
  pgTable,
  serial,
  text,
  bigint,
  integer,
  numeric,
  timestamp,
  boolean,
  index,
} from "drizzle-orm/pg-core";

// All Telegram users who started the bot
export const users = pgTable(
  "users",
  {
    id: serial("id").primaryKey(),
    telegramId: bigint("telegram_id", { mode: "number" }).notNull().unique(),
    username: text("username"),
    firstName: text("first_name"),
    lastName: text("last_name"),
    referredBy: bigint("referred_by", { mode: "number" }), // telegram_id of referrer
    isAdmin: boolean("is_admin").default(false).notNull(),
    joinedAt: timestamp("joined_at").defaultNow().notNull(),
  },
  (t) => [index("users_telegram_id_idx").on(t.telegramId)]
);

// Referral link records per user
export const referralLinks = pgTable(
  "referral_links",
  {
    id: serial("id").primaryKey(),
    ownerId: bigint("owner_id", { mode: "number" }).notNull(), // telegram_id
    ownerUsername: text("owner_username"),
    code: text("code").notNull().unique(), // e.g. "xleremy"
    clickCount: integer("click_count").default(0).notNull(),
    referredCount: integer("referred_count").default(0).notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (t) => [
    index("referral_links_owner_idx").on(t.ownerId),
    index("referral_links_code_idx").on(t.code),
  ]
);

// Purchase records — simulates purchases made by referred users
export const purchases = pgTable(
  "purchases",
  {
    id: serial("id").primaryKey(),
    buyerTelegramId: bigint("buyer_telegram_id", { mode: "number" }).notNull(),
    referrerTelegramId: bigint("referrer_telegram_id", { mode: "number" }), // who gets the commission
    amount: numeric("amount", { precision: 12, scale: 2 }).notNull(), // purchase amount in rubles
    commission: numeric("commission", { precision: 12, scale: 2 }).notNull(), // 50% of amount
    description: text("description"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (t) => [
    index("purchases_buyer_idx").on(t.buyerTelegramId),
    index("purchases_referrer_idx").on(t.referrerTelegramId),
  ]
);

// Earnings summary per user (denormalized for fast leaderboard)
export const earnings = pgTable(
  "earnings",
  {
    id: serial("id").primaryKey(),
    telegramId: bigint("telegram_id", { mode: "number" }).notNull().unique(),
    username: text("username"),
    firstName: text("first_name"),
    totalEarned: numeric("total_earned", { precision: 12, scale: 2 })
      .default("0")
      .notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (t) => [
    index("earnings_telegram_id_idx").on(t.telegramId),
    index("earnings_total_earned_idx").on(t.totalEarned),
  ]
);

// Bot activity log for admin
export const botLogs = pgTable("bot_logs", {
  id: serial("id").primaryKey(),
  telegramId: bigint("telegram_id", { mode: "number" }),
  username: text("username"),
  action: text("action").notNull(),
  detail: text("detail"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
