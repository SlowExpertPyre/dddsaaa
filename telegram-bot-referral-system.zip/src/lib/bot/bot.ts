import { Telegraf, Context, Markup } from "telegraf";
import {
  getOrCreateUser,
  getUserByTelegramId,
  getReferralLink,
  getAllReferralLinksWithStats,
  getTopEarners,
  getEarningsByTelegramId,
  getTotalStats,
  getAllUsers,
  recordPurchase,
  logAction,
  formatMoney,
  displayName,
  incrementLinkClick,
  getRecentPurchases,
} from "./helpers";
import { db } from "@/db";
import { users, referralLinks } from "@/db/schema";
import { eq } from "drizzle-orm";

const TOKEN = process.env.TELEGRAM_BOT_TOKEN ?? "";
const ADMIN_IDS = (process.env.ADMIN_TELEGRAM_IDS ?? "")
  .split(",")
  .map((s) => parseInt(s.trim()))
  .filter((n) => !isNaN(n) && n > 0);
const BOT_USERNAME = process.env.TELEGRAM_BOT_USERNAME ?? "myrefbot";

function isAdmin(telegramId: number): boolean {
  return ADMIN_IDS.includes(telegramId);
}

// Medals for leaderboard
const MEDALS = ["🥇", "🥈", "🥉", "4️⃣", "5️⃣"];

export function createBot() {
  if (!TOKEN) {
    console.warn("TELEGRAM_BOT_TOKEN not set — bot will not start");
    return null;
  }

  const bot = new Telegraf(TOKEN);

  // ─── /start ──────────────────────────────────────────────────────────────
  bot.start(async (ctx) => {
    const { id, username, first_name, last_name } = ctx.from;
    const payload = ctx.startPayload; // referral code from ?start=CODE

    // If it's a click-through (not a real /start in private), increment click
    if (payload) {
      await incrementLinkClick(payload).catch(() => {});
    }

    const user = await getOrCreateUser(
      id,
      username,
      first_name,
      last_name,
      payload || undefined
    );

    const link = await getReferralLink(id);
    const refUrl = link
      ? `https://t.me/${BOT_USERNAME}?start=${link.code}`
      : "—";

    const msg =
      `👋 Welcome, <b>${first_name}</b>!\n\n` +
      `🔗 Your referral link:\n<code>${refUrl}</code>\n\n` +
      `Share it and earn <b>50% commission</b> on every purchase your referrals make!\n\n` +
      `📋 Commands:\n` +
      `/mylink — your referral link & stats\n` +
      `/mystats — your earnings\n` +
      `/statistics — top-5 earners leaderboard`;

    await ctx.replyWithHTML(msg);

    // Notify admin if someone joined via a referral
    if (user.referredBy && payload) {
      const referrer = await getUserByTelegramId(user.referredBy);
      const referrerName = displayName(referrer?.username, referrer?.firstName);
      const newUserName = displayName(username, first_name);

      for (const adminId of ADMIN_IDS) {
        try {
          await ctx.telegram.sendMessage(
            adminId,
            `🆕 <b>New referral!</b>\n\n` +
              `👤 New user: ${newUserName} (<code>${id}</code>)\n` +
              `🔗 Via referral: <b>${referrerName}</b> (code: <code>${payload}</code>)\n` +
              `📅 ${new Date().toLocaleString("en-GB")}`,
            { parse_mode: "HTML" }
          );
        } catch {
          // admin not reachable
        }
      }
    }
  });

  // ─── /mylink ─────────────────────────────────────────────────────────────
  bot.command("mylink", async (ctx) => {
    const { id, username, first_name } = ctx.from;
    await getOrCreateUser(id, username, first_name);

    const link = await getReferralLink(id);
    if (!link) {
      await ctx.reply("⚠️ No referral link found. Use /start first.");
      return;
    }

    const refUrl = `https://t.me/${BOT_USERNAME}?start=${link.code}`;

    await ctx.replyWithHTML(
      `🔗 <b>Your Referral Link</b>\n\n` +
        `<code>${refUrl}</code>\n\n` +
        `📊 <b>Stats</b>\n` +
        `👆 Clicks: <b>${link.clickCount}</b>\n` +
        `👥 Joined via your link: <b>${link.referredCount}</b>\n\n` +
        `💡 Share your link and earn <b>50%</b> of every purchase your referrals make!`
    );
  });

  // ─── /mystats ────────────────────────────────────────────────────────────
  bot.command("mystats", async (ctx) => {
    const { id, username, first_name } = ctx.from;
    await getOrCreateUser(id, username, first_name);

    const [link, earned] = await Promise.all([
      getReferralLink(id),
      getEarningsByTelegramId(id),
    ]);

    const refUrl = link
      ? `https://t.me/${BOT_USERNAME}?start=${link.code}`
      : "—";

    await ctx.replyWithHTML(
      `📈 <b>Your Stats</b>\n\n` +
        `🔗 Referral link: <code>${refUrl}</code>\n` +
        `👥 People joined: <b>${link?.referredCount ?? 0}</b>\n` +
        `👆 Link clicks: <b>${link?.clickCount ?? 0}</b>\n\n` +
        `💰 <b>Total earned: ${formatMoney(earned?.totalEarned ?? 0)}</b>\n\n` +
        `ℹ️ You earn 50% of each purchase made by your referrals.`
    );
  });

  // ─── /statistics (public leaderboard) ────────────────────────────────────
  bot.command("statistics", async (ctx) => {
    const { id, username, first_name } = ctx.from;
    await getOrCreateUser(id, username, first_name);

    const top = await getTopEarners(5);

    if (top.length === 0) {
      await ctx.replyWithHTML(
        "📊 <b>Top Earners</b>\n\nNo earnings recorded yet. Be the first!"
      );
      return;
    }

    let text = "🏆 <b>Top-5 Earners</b>\n\n";
    top.forEach((row, i) => {
      const name = displayName(row.username, row.firstName);
      text += `${MEDALS[i]} ${name} — <b>${formatMoney(row.totalEarned)}</b>\n`;
    });

    text +=
      "\n💡 Share your referral link (/mylink) and climb the leaderboard!";

    await ctx.replyWithHTML(text);
  });

  // ─── /admin ───────────────────────────────────────────────────────────────
  bot.command("admin", async (ctx) => {
    const { id } = ctx.from;
    if (!isAdmin(id)) {
      await ctx.reply("⛔ Access denied.");
      return;
    }

    await ctx.replyWithHTML(
      "🔧 <b>Admin Panel</b>\n\n" +
        "Commands:\n" +
        "/admin_stats — overall bot statistics\n" +
        "/admin_links — all referral links & stats\n" +
        "/admin_users — all registered users\n" +
        "/admin_purchases — recent purchases\n" +
        "/admin_add_purchase [userId] [amount] [desc] — record a purchase\n" +
        "/admin_top — top earners (extended)"
    );
    await logAction(id, ctx.from.username, "ADMIN_PANEL");
  });

  // ─── /admin_stats ─────────────────────────────────────────────────────────
  bot.command("admin_stats", async (ctx) => {
    const { id } = ctx.from;
    if (!isAdmin(id)) {
      await ctx.reply("⛔ Access denied.");
      return;
    }

    const stats = await getTotalStats();

    await ctx.replyWithHTML(
      `📊 <b>Overall Bot Statistics</b>\n\n` +
        `👥 Total users: <b>${stats.users}</b>\n` +
        `🔗 Referral links: <b>${stats.links}</b>\n` +
        `🛒 Total purchases: <b>${stats.purchases}</b>\n` +
        `💵 Total revenue: <b>${formatMoney(stats.totalRevenue)}</b>\n` +
        `💸 Total commissions paid: <b>${formatMoney(stats.totalCommissions)}</b>\n` +
        `📅 Generated: ${new Date().toLocaleString("en-GB")}`
    );
    await logAction(id, ctx.from.username, "ADMIN_STATS");
  });

  // ─── /admin_links ─────────────────────────────────────────────────────────
  bot.command("admin_links", async (ctx) => {
    const { id } = ctx.from;
    if (!isAdmin(id)) {
      await ctx.reply("⛔ Access denied.");
      return;
    }

    const links = await getAllReferralLinksWithStats();
    if (links.length === 0) {
      await ctx.reply("No referral links yet.");
      return;
    }

    let text = `🔗 <b>All Referral Links (${links.length})</b>\n\n`;
    links.slice(0, 30).forEach((l, i) => {
      const owner = displayName(l.ownerUsername, null);
      const url = `https://t.me/${BOT_USERNAME}?start=${l.code}`;
      text +=
        `${i + 1}. ${owner} — code: <code>${l.code}</code>\n` +
        `   👆 Clicks: ${l.clickCount} | 👥 Joined: ${l.referredCount}\n` +
        `   🔗 <a href="${url}">${url}</a>\n\n`;
    });

    if (links.length > 30) text += `… and ${links.length - 30} more.`;

    await ctx.replyWithHTML(text, { disable_web_page_preview: true } as any);
    await logAction(id, ctx.from.username, "ADMIN_LINKS");
  });

  // ─── /admin_users ─────────────────────────────────────────────────────────
  bot.command("admin_users", async (ctx) => {
    const { id } = ctx.from;
    if (!isAdmin(id)) {
      await ctx.reply("⛔ Access denied.");
      return;
    }

    const allUsers = await getAllUsers();
    if (allUsers.length === 0) {
      await ctx.reply("No users yet.");
      return;
    }

    let text = `👥 <b>All Users (${allUsers.length})</b>\n\n`;
    allUsers.slice(0, 25).forEach((u, i) => {
      const name = displayName(u.username, u.firstName);
      const ref = u.referredBy ? `ref: ${u.referredBy}` : "organic";
      text += `${i + 1}. ${name} <code>${u.telegramId}</code> (${ref})\n`;
    });
    if (allUsers.length > 25) text += `\n… and ${allUsers.length - 25} more.`;

    await ctx.replyWithHTML(text);
    await logAction(id, ctx.from.username, "ADMIN_USERS");
  });

  // ─── /admin_purchases ─────────────────────────────────────────────────────
  bot.command("admin_purchases", async (ctx) => {
    const { id } = ctx.from;
    if (!isAdmin(id)) {
      await ctx.reply("⛔ Access denied.");
      return;
    }

    const recent = await getRecentPurchases(20);
    if (recent.length === 0) {
      await ctx.reply("No purchases yet.");
      return;
    }

    let text = `🛒 <b>Recent Purchases (${recent.length})</b>\n\n`;
    recent.forEach((p) => {
      text +=
        `👤 Buyer: <code>${p.buyerTelegramId}</code>\n` +
        `💵 Amount: <b>${formatMoney(p.amount)}</b> | Commission: <b>${formatMoney(p.commission)}</b>\n` +
        (p.referrerTelegramId
          ? `🔗 Referrer: <code>${p.referrerTelegramId}</code>\n`
          : "") +
        (p.description ? `📝 ${p.description}\n` : "") +
        `📅 ${new Date(p.createdAt).toLocaleString("en-GB")}\n\n`;
    });

    await ctx.replyWithHTML(text);
    await logAction(id, ctx.from.username, "ADMIN_PURCHASES");
  });

  // ─── /admin_add_purchase [telegramId] [amount] [description] ──────────────
  bot.command("admin_add_purchase", async (ctx) => {
    const { id } = ctx.from;
    if (!isAdmin(id)) {
      await ctx.reply("⛔ Access denied.");
      return;
    }

    const parts = ctx.message.text.split(" ").slice(1);
    const buyerId = parseInt(parts[0]);
    const amount = parseFloat(parts[1]);
    const desc = parts.slice(2).join(" ") || undefined;

    if (isNaN(buyerId) || isNaN(amount) || amount <= 0) {
      await ctx.reply(
        "⚠️ Usage: /admin_add_purchase [telegramId] [amount] [description]\nExample: /admin_add_purchase 123456789 500 Premium subscription"
      );
      return;
    }

    const buyer = await getUserByTelegramId(buyerId);
    if (!buyer) {
      await ctx.reply(`⚠️ User ${buyerId} not found in database.`);
      return;
    }

    const { commission, referrerTelegramId } = await recordPurchase(
      buyerId,
      amount,
      desc
    );

    let msg =
      `✅ <b>Purchase recorded!</b>\n\n` +
      `👤 Buyer: ${displayName(buyer.username, buyer.firstName)} (<code>${buyerId}</code>)\n` +
      `💵 Amount: <b>${formatMoney(amount)}</b>\n` +
      `💸 Commission (50%): <b>${formatMoney(commission)}</b>\n`;

    if (referrerTelegramId) {
      const referrer = await getUserByTelegramId(referrerTelegramId);
      const rName = displayName(referrer?.username, referrer?.firstName);
      msg += `🔗 Credited to referrer: ${rName} (<code>${referrerTelegramId}</code>)`;

      // Notify referrer in DM
      try {
        await ctx.telegram.sendMessage(
          referrerTelegramId,
          `🎉 <b>You earned a commission!</b>\n\n` +
            `Your referral ${displayName(buyer.username, buyer.firstName)} just made a purchase of <b>${formatMoney(amount)}</b>.\n` +
            `💰 Your commission (50%): <b>${formatMoney(commission)}</b>\n\n` +
            `Use /mystats to see your total earnings!`,
          { parse_mode: "HTML" }
        );
      } catch {
        // referrer hasn't started the bot
      }
    } else {
      msg += `ℹ️ No referrer — this user joined organically.`;
    }

    await ctx.replyWithHTML(msg);
    await logAction(id, ctx.from.username, "ADMIN_ADD_PURCHASE", `buyer=${buyerId} amount=${amount}`);
  });

  // ─── /admin_top ───────────────────────────────────────────────────────────
  bot.command("admin_top", async (ctx) => {
    const { id } = ctx.from;
    if (!isAdmin(id)) {
      await ctx.reply("⛔ Access denied.");
      return;
    }

    const top = await getTopEarners(10);
    if (top.length === 0) {
      await ctx.reply("No earnings yet.");
      return;
    }

    let text = "🏆 <b>Top Earners (Admin View)</b>\n\n";
    top.forEach((row, i) => {
      const name = displayName(row.username, row.firstName);
      text += `${i + 1}. ${name} <code>${row.telegramId}</code> — <b>${formatMoney(row.totalEarned)}</b>\n`;
    });

    await ctx.replyWithHTML(text);
    await logAction(id, ctx.from.username, "ADMIN_TOP");
  });

  // ─── Unknown commands ─────────────────────────────────────────────────────
  bot.on("text", async (ctx) => {
    if (ctx.message.text.startsWith("/")) {
      await ctx.reply(
        "❓ Unknown command. Use:\n/mylink /mystats /statistics\n" +
          (isAdmin(ctx.from.id) ? "/admin /admin_stats /admin_links /admin_users /admin_purchases /admin_top /admin_add_purchase" : "")
      );
    }
  });

  return bot;
}
