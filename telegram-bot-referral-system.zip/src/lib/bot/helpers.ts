import { db } from "@/db";
import {
  users,
  referralLinks,
  purchases,
  earnings,
  botLogs,
} from "@/db/schema";
import { eq, sql, desc } from "drizzle-orm";

// ─── User helpers ────────────────────────────────────────────────────────────

export async function getOrCreateUser(
  telegramId: number,
  username?: string,
  firstName?: string,
  lastName?: string,
  referralCode?: string
) {
  const existing = await db
    .select()
    .from(users)
    .where(eq(users.telegramId, telegramId))
    .limit(1);

  if (existing.length > 0) return existing[0];

  // Resolve referrer from code
  let referredBy: number | undefined;
  if (referralCode) {
    const link = await db
      .select()
      .from(referralLinks)
      .where(eq(referralLinks.code, referralCode))
      .limit(1);
    if (link.length > 0 && link[0].ownerId !== telegramId) {
      referredBy = link[0].ownerId;

      // Increment referred count on link
      await db
        .update(referralLinks)
        .set({ referredCount: sql`${referralLinks.referredCount} + 1` })
        .where(eq(referralLinks.code, referralCode));
    }
  }

  const [newUser] = await db
    .insert(users)
    .values({
      telegramId,
      username,
      firstName,
      lastName,
      referredBy,
    })
    .returning();

  // Create default referral link for the new user (uses username or id)
  const code = username ?? `user${telegramId}`;
  const existing2 = await db
    .select()
    .from(referralLinks)
    .where(eq(referralLinks.code, code))
    .limit(1);
  if (existing2.length === 0) {
    await db.insert(referralLinks).values({
      ownerId: telegramId,
      ownerUsername: username,
      code,
    });
  }

  // Ensure earnings row exists
  await ensureEarningsRow(telegramId, username, firstName);

  await logAction(telegramId, username, "JOIN", referredBy ? `via ${referralCode}` : "organic");

  return newUser;
}

export async function getUserByTelegramId(telegramId: number) {
  const rows = await db
    .select()
    .from(users)
    .where(eq(users.telegramId, telegramId))
    .limit(1);
  return rows[0] ?? null;
}

// ─── Referral helpers ────────────────────────────────────────────────────────

export async function getReferralLink(telegramId: number) {
  const rows = await db
    .select()
    .from(referralLinks)
    .where(eq(referralLinks.ownerId, telegramId))
    .limit(1);
  return rows[0] ?? null;
}

export async function getAllReferralLinksWithStats() {
  // owner info joined
  const rows = await db
    .select({
      id: referralLinks.id,
      code: referralLinks.code,
      ownerId: referralLinks.ownerId,
      ownerUsername: referralLinks.ownerUsername,
      clickCount: referralLinks.clickCount,
      referredCount: referralLinks.referredCount,
      createdAt: referralLinks.createdAt,
    })
    .from(referralLinks)
    .orderBy(desc(referralLinks.referredCount));
  return rows;
}

export async function incrementLinkClick(code: string) {
  await db
    .update(referralLinks)
    .set({ clickCount: sql`${referralLinks.clickCount} + 1` })
    .where(eq(referralLinks.code, code));
}

// ─── Purchase & earnings ─────────────────────────────────────────────────────

export async function recordPurchase(
  buyerTelegramId: number,
  amount: number,
  description?: string
) {
  // Find referrer
  const buyer = await getUserByTelegramId(buyerTelegramId);
  const referrerTelegramId = buyer?.referredBy ?? null;
  const commission = +(amount * 0.5).toFixed(2);

  const [purchase] = await db
    .insert(purchases)
    .values({
      buyerTelegramId,
      referrerTelegramId,
      amount: amount.toString(),
      commission: commission.toString(),
      description,
    })
    .returning();

  // Credit referrer earnings
  if (referrerTelegramId) {
    await db
      .insert(earnings)
      .values({
        telegramId: referrerTelegramId,
        totalEarned: commission.toString(),
      })
      .onConflictDoUpdate({
        target: earnings.telegramId,
        set: {
          totalEarned: sql`${earnings.totalEarned} + ${commission}`,
          updatedAt: sql`now()`,
        },
      });
  }

  return { purchase, commission, referrerTelegramId };
}

// ─── Leaderboard ─────────────────────────────────────────────────────────────

export async function getTopEarners(limit = 5) {
  const rows = await db
    .select()
    .from(earnings)
    .orderBy(desc(earnings.totalEarned))
    .limit(limit);
  return rows;
}

export async function getEarningsByTelegramId(telegramId: number) {
  const rows = await db
    .select()
    .from(earnings)
    .where(eq(earnings.telegramId, telegramId))
    .limit(1);
  return rows[0] ?? null;
}

// ─── Admin ───────────────────────────────────────────────────────────────────

export async function getTotalStats() {
  const [userCount] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(users);
  const [linkCount] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(referralLinks);
  const [purchaseStats] = await db.select({
    count: sql<number>`count(*)::int`,
    total: sql<string>`coalesce(sum(amount),0)::text`,
    commissions: sql<string>`coalesce(sum(commission),0)::text`,
  }).from(purchases);
  const [earningsStats] = await db.select({
    total: sql<string>`coalesce(sum(total_earned),0)::text`,
  }).from(earnings);

  return {
    users: userCount.count,
    links: linkCount.count,
    purchases: purchaseStats.count,
    totalRevenue: purchaseStats.total,
    totalCommissions: purchaseStats.commissions,
    totalPaidOut: earningsStats.total,
  };
}

export async function getAllUsers() {
  return db.select().from(users).orderBy(desc(users.joinedAt));
}

export async function getRecentPurchases(limit = 20) {
  return db.select().from(purchases).orderBy(desc(purchases.createdAt)).limit(limit);
}

// ─── Misc ────────────────────────────────────────────────────────────────────

export async function ensureEarningsRow(
  telegramId: number,
  username?: string,
  firstName?: string
) {
  await db
    .insert(earnings)
    .values({ telegramId, username, firstName, totalEarned: "0" })
    .onConflictDoUpdate({
      target: earnings.telegramId,
      set: { username, firstName },
    });
}

export async function logAction(
  telegramId: number | null,
  username: string | undefined,
  action: string,
  detail?: string
) {
  await db.insert(botLogs).values({ telegramId, username, action, detail });
}

export function formatMoney(val: string | number | null | undefined): string {
  const n = parseFloat(String(val ?? "0"));
  return n.toLocaleString("ru-RU", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + " ₽";
}

export function displayName(
  username?: string | null,
  firstName?: string | null
): string {
  if (username) return `@${username}`;
  if (firstName) return firstName;
  return "Unknown";
}
